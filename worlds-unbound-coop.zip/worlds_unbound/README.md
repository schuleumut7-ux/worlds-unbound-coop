# Worlds Unbound — 2 Player Co-op

A browser-based 2D top-down co-op adventure foundation with room codes, real-time player synchronization, 8 themed worlds, combat, boss state, local save, responsive HUD and mobile joystick.

## Run
1. Install Node.js 18+.
2. In this folder run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000` in two browser windows/devices.
5. Create a room in one window and join using the 5-character code in the other.

For LAN play use the host computer's local IP instead of localhost. For internet play deploy the Node server behind HTTPS/WSS.

## Controls
WASD / arrow keys to move. Space or Attack to strike. Ability / Dodge buttons work on touch and mouse. Mobile has a virtual joystick.

## Architecture
`index.html` shell and UI · `style.css` responsive presentation · `game.js` rendering/input/game systems · `server.js` authoritative rooms and player snapshots.

This is an expandable vertical slice rather than eight full production-sized worlds. The architecture leaves room to add content without replacing the networking foundation.
