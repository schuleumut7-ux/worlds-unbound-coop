import { WebSocketServer } from 'ws';
import { randomBytes } from 'crypto';
const PORT=process.env.PORT||3000; const wss=new WebSocketServer({port:PORT}); const rooms=new Map();
const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function code(){let s=''; do{s=[0,0,0,0,0].map(()=>chars[Math.floor(Math.random()*chars.length)]).join('')}while(rooms.has(s)); return s}
function send(ws,type,data={}){if(ws.readyState===1)ws.send(JSON.stringify({type,...data}))}
function broadcast(room,type,data={},except=null){for(const p of room.players.values())if(p.ws!==except)send(p.ws,type,data)}
function snapshot(room){return [...room.players.values()].map(p=>({id:p.id,name:p.name,x:p.x,y:p.y,hp:p.hp,maxHp:p.maxHp,downed:p.downed,coins:p.coins,level:p.level,world:p.world}))}
function roomState(room){return {code:room.code,host:room.host,world:room.world,players:snapshot(room),quests:room.quests,bossHp:room.bossHp}}
wss.on('connection',ws=>{ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return} if(!m||typeof m.type!=='string')return;
 if(m.type==='create'){const r={code:code(),host:null,world:1,players:new Map(),quests:{forestBoss:false},bossHp:1000}; const id=randomBytes(4).toString('hex'); const p={id,ws,name:String(m.name||'Hero').slice(0,16),x:800,y:600,hp:100,maxHp:100,downed:false,coins:50,level:1,world:1}; r.host=id;r.players.set(id,p);rooms.set(r.code,r);ws.room=r;ws.pid=id;send(ws,'roomCreated',{code:r.code,id});send(ws,'state',roomState(r));return}
 if(m.type==='join'){const r=rooms.get(String(m.code||'').toUpperCase());if(!r||r.players.size>=2)return send(ws,'error',{message:'Room not found or full.'});const id=randomBytes(4).toString('hex');const p={id,ws,name:String(m.name||'Hero').slice(0,16),x:880,y:600,hp:100,maxHp:100,downed:false,coins:50,level:1,world:r.world};r.players.set(id,p);ws.room=r;ws.pid=id;send(ws,'joined',{code:r.code,id});broadcast(r,'state',roomState(r));send(ws,'state',roomState(r));return}
 const r=ws.room,p=r?.players.get(ws.pid); if(!r||!p)return;
 if(m.type==='input'){p.x=Math.max(60,Math.min(1540,Number(m.x)||p.x));p.y=Math.max(60,Math.min(1140,Number(m.y)||p.y));p.downed=!!m.downed; p.hp=Math.max(0,Math.min(p.maxHp,Number(m.hp)||p.hp));broadcast(r,'state',roomState(r));}
 if(m.type==='event'){if(m.event==='bossHit'){r.bossHp=Math.max(0,r.bossHp-(Number(m.damage)||20)); if(r.bossHp===0)r.quests.forestBoss=true; broadcast(r,'worldEvent',{event:m.event,bossHp:r.bossHp,quests:r.quests})} else broadcast(r,'worldEvent',{event:m.event,by:p.id,data:m.data||{}})}
 if(m.type==='world'){const w=Math.max(1,Math.min(8,Number(m.world)||1));if(p.id===r.host){r.world=w;r.bossHp=1000;for(const q of r.players.values())q.world=w;broadcast(r,'state',roomState(r))}}
 }); ws.on('close',()=>{const r=ws.room;if(!r)return;r.players.delete(ws.pid);if(r.players.size===0){rooms.delete(r.code)}else{if(r.host===ws.pid)r.host=r.players.keys().next().value;broadcast(r,'state',roomState(r))}})});
console.log(`Worlds Unbound server on ws://localhost:${PORT}`);
